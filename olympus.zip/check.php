<?php
	$day = $_POST['day'];
	$moth= $_POST['month'];
	$year = $_POST['year'];
	$date = $day.'/'.$moth.'/'.$year;
	echo $date;

?>