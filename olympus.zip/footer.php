

<div class="container-fluid">
  <div class="row" id="footer" style="background: #333;color: #fff;">
    
        <div class="col-md-4">

            <h2 class="footer-title">Giới Thiệu</h2>
            <div class="tx-div"></div>
            <p id="txtfoot">Tôi luôn Sống Tràn Đầy Năng Lượng để Tài Năng Tỏa Sáng. Tôi Khát Vọng, Cá Tính, Hiện Đại.
Tôi là vậy đó ! </p>
            
            </p>
<!-- GoStats JavaScript Based Code -->

<!-- End GoStats JavaScript Based Code -->

        </div>
        <div class="col-md-4">
            <h3 class="footer-title">Liên hệ</h3>
            <div class="tx-div"></div>
            <p id="txtfoot"><i class="fa fa-map-marker" aria-hidden="true"></i> Lầu 1, Nhà B3, KTX khu B, ĐHQG.<br>
            <img src="https://cdn2.iconfinder.com/data/icons/social-icons-circular-color/512/gmail-24.png"> Email: Olympusgym.info@gmail.com<br>
            <img src="https://cdn2.iconfinder.com/data/icons/social-icons-color/512/whatsapp-24.png"> 0122 658 3219<br>
            <img src="https://cdn2.iconfinder.com/data/icons/social-icons-circular-color/512/fb-24.png"><a href="https://www.facebook.com/ThoaSucVuonCao/?fref=ts"> <b>OlymPus Gym</b></a></p>

	</div>
        <div class="col-md-4">
            <h3 class="footer-title">Liên Kết Bạn Bè</h3>
            <div class="tx-div"></div>
            
	            <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FThoaSucVuonCao%2F%3Ffref%3Dts&tabs=timeline&width=340&height=200&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="200" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>

        </div>
    
  </div>
</div>